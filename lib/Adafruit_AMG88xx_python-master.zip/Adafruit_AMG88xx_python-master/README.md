
DEPRECATED LIBRARY Adafruit_AMG88xx_python
===================

This library has been deprecated!

We are currently only supporting the circuitpython version of this library - it works great on Raspi/Linux and easier for us to maintain. 

we are leaving the code up for historical/research purposes but archiving the repository.

check out this guide for using the amg8833 with python!
https://learn.adafruit.com/adafruit-amg8833-8x8-thermal-camera-sensor
